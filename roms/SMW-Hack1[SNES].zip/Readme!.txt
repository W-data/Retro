;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
Hooray for games!

This is a mini game Cypher made over the course of a few days. However, it doesn't play like any other game on the site. (At least none
that I know of...) You can play this game in single player, but then you can't beat the whole thing! You will need a second player in the
latter stages because you two work together at the same time to beat a couple levels. The rest of the time player 2 can try to kill you
since they control the enemies!

If you see a small '!' above an enemies head, that means player 2 has control of that enemy. Enemies are controlled the same way you
would control Mario, however the controls feel stiffer but whatever. Oh yeah, you can make most of the enemies fly, levitate and just
generally break the laws of physics. If you wish to delete that sprite and control a different one on the screen, press start.

Mario starts off with 10 lives instead of 5 because having human controlled enemies is a lot tougher than the regular programmed sprites.

I would like to thank project bottles!
	-Cyphermur9t
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;